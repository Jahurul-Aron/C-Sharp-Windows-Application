﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LoginFormApp
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-TVMDMIE;Initial Catalog=userlogin;Integrated Security=True");
            //con.Open();
            //string UeerName = textBox1.Text;
            //string Password = textBox2.Text;
            SqlCommand cmd = new SqlCommand("select UserName,Password from Logintb where UserName='" + textBox1.Text + "'and Password='" + textBox2.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                FromLoggin obj = new FromLoggin();
                this.Hide();
                obj.Show();
            }
            else
            {
                MessageBox.Show("Invalid Login please check username and password");
            }
            //con.Close();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    }

