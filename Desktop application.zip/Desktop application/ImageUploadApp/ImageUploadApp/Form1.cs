﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImageUploadApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'myimage.Imagetable' table. You can move, or remove it, as needed.
            this.imagetableTableAdapter.Fill(this.myimage.Imagetable);

        }

        private void imagetableBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.imagetableBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.myimage);

        }

        private void nameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void imgPictureBox_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            // image filters
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp;";
            if (open.ShowDialog() == DialogResult.OK)
            {
                // display image in picture box
                //imgPictureBox.Image = new Bitmap(open.FileName);
                imgPictureBox.Image = Image.FromFile(open.FileName);


                // image file path
                imgpathLabel1.Text = open.FileName;
            }
        }

        private void imgpathLabel1_Click(object sender, EventArgs e)
        {

        }
    }
}
